<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package MMI_TD
 */

?>

	<footer id="colophon" class="site-footer">
	<footer class="flex flex-col gap-8 p-2">

		<ul class="flex flex-col justify-center items-center gap-4 md:flex-row list-none">
		<li class="flex flex-col justify-center items-center gap-2 font-lato font-thin">
			<img class="w-12 object-cover" src="assets/Icons/Livraison.svg" alt="">
			Livraison offerte dès 45€*
		</li>
		<li class="flex flex-col justify-center items-center gap-2 font-lato font-thin">
			<img class="w-12 object-cover" src="assets/Icons/CetC.svg" alt="">
			Click & Collect gratuit
		</li>
		<li class="flex flex-col justify-center items-center gap-2 font-lato font-thin">
			<img class="w-12 object-cover" src="assets/Icons/CarteSecure.svg" alt="">
			Paiement sécurisé
		</li>
		<li class="flex flex-col justify-center items-center gap-2 font-lato font-thin">
			<img class="w-12 object-cover" src="assets/Icons/Fidélité.svg" alt="">
			Programme de fidélité
		</li>
		</ul>

		<figure class="bg-grey200 w-full h-0.5"></figure>

		<ul class="flex flex-wrap gap-4 md:flex-row md:justify-between list-none">
		<li class="font-lato font-thin text-sm">
			<ul class="flex flex-wrap gap-4 flex-col list-none">
			<li class="font-lato uppercase font-bold text-base">Kusmi tea</li>
			<li class="font-lato font-thin text-sm">La marque</li>
			<li class="font-lato font-thin text-sm">Programme de fidélité</li>
			<li class="font-lato font-thin text-sm">Trouver une boutique Kusmi</li>
			<li class="font-lato font-thin text-sm">Notre conversion au bio</li>
			<li class="font-lato font-thin text-sm">Nos engagements pour la planète</li>
			<li class="font-lato font-thin text-sm">Lov Organic devient Kusmi Bio</li>
			<li class="font-lato font-thin text-sm">Rituel, notre cure bio à la vitamine C</li>
			<li class="font-lato font-thin text-sm">Consignes de tri</li>
			<li class="font-lato font-thin text-sm">Plan du site</li>
			</ul>
		</li>
		<li class="font-lato font-thin text-sm">
			<ul class="flex flex-wrap gap-4 flex-col list-none">
			<li class="font-lato font-bold text-base">Professionnels</li>
			<li class="font-lato font-thin text-sm">Cadeaux d'affaires</li>
			<li class="font-lato font-thin text-sm">Site professionnel</li>
			<li class="font-lato font-thin text-sm">Devenir client professionnel</li>
			<li class="font-lato font-thin text-sm">Offres d'emploi</li>
			</ul>
		</li>
		<li>
			<ul class="flex flex-wrap gap-4 flex-col list-none">
			<li class="font-lato font-bold text-base">Assistance</li>
			<li class="font-lato font-thin text-sm">Aide et contact</li>
			<li class="font-lato font-thin text-sm">Livraison</li>
			<li class="font-lato font-thin text-sm">Click & Collect</li>
			<li class="font-lato font-thin text-sm">Avantages et garanties</li>
			<li class="font-lato font-thin text-sm">FAQ</li>
			<li class="font-lato font-thin text-sm">Mentions légales/CGVU</li>
			<li class="font-lato font-thin text-sm">Politique de confidentialité</li>
			<li class="font-lato font-thin text-sm">Paramétrer</li>
			</ul>
		</li>
		<li class="font-lato uppercase font-bold text-base">Conditions des offres</li>
		</ul>

		<ul class="flex flex-col gap-4 justify-center items-center text-center list-none">

		<li class="font-lato font-thin text-sm">ORIENTIS GOURMET, 89 avenue Niel, 75017 Paris, 350 283 057 RCS Paris.</li>
		<li class="font-lato font-thin text-sm">Pour les bouilloires et les machines à thé, nous vous Informons que vous bénéficiez d'une garantie légale de conformíté d'une durèe de deux ans à compter de la date de votre achat.</li>
		<li class="font-lato font-thin text-sm">La maison de thé Kusmi Tea, marque française, made in Normandie, cultive la tradition du thé bio depuis 1867. Guidée par la passion et par la recherche d’innovation permanente, Kusmi Tea est devenue une référence mondiale dans la vente de thé en vrac et sachets, d’infusions bio et de coffrets pour le thé. Thé nature ou thé arômatisé, thé japonais, thé de Chine ou encore thé d’Inde, thé vert, thé noir, thé blanc, matcha, rooibos ou maté… vous trouverez forcément votre bonheur !</li>
		<li class="font-lato font-thin text-sm">Nos recettes emblématiques ? Les voici : Anastasia, genmaicha, thé vert à la menthe, Earl Grey, Tropical White, Blue Detox, Vert gingembre citron, Matcha bio, Prince Vladimir, English Breakfast, Bouquet de fleurs, Tchai of the Tiger, Rooibos Amande, BB Detox, Coffret Kusmi Découverte, Coffret Les Bien-être, Glögg, Christmas in Paris bio, Tsarevna et notre dernière nouveauté Rituel Défenses Immunitaires bio (cure de vitamine C à base de thé vert et d'acérola) !</li>
		<li class="font-lato font-thin text-sm">Fan d'un ingrédient en particulier ? Choisissez votre thé ou votre tisane en fonction de sa composition : pomme, bergamote, réglisse, gingembre, orange, cannelle, fruits rouges, fruits tropicaux, cardamone, citron, hibiscus. Découvrez également notre sélection de thés et infusions bio pour le matin, l'après-repas, le soir et le tea time !</li>
		<li class="font-lato font-thin text-sm">Une fois que vous avez trouvé votre thé, optez pour nos accessoires pour préparer et déguster votre thé : théières, filtres à thé et infuseurs, tasses et mugs, et accessoires isothermes tels que les bouteilles isothermes et les tisanières.</li>

		</ul>

	</footer>
        <nav id="footer-navigation" class="footer-navigation">
			<button class="menu-toggle" aria-controls="footer-menu" aria-expanded="false"><?php esc_html_e( 'Primary Menu', 'mmi-td' ); ?></button>
			<?php
			?>
		</nav><!-- #site-navigation -->
		<div class="site-info self">
			<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'mmi-td' ) ); ?>">
				<?php
				/* translators: %s: CMS name, i.e. WordPress. */
				printf( esc_html__( 'Proudly powered by %s', 'mmi-td' ), 'WordPress' );
				?>
			</a>
			<span class="sep"> | </span>
				<?php
				/* translators: 1: Theme name, 2: Theme author. */
				printf( esc_html__( 'Theme: %1$s by %2$s.', 'mmi-td' ), 'mmi-td', '<a href="http://underscores.me/">Underscores.me</a>' );
				?>
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
