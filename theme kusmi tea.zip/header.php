<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package MMI_TD
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'mmi-td' ); ?></a>

	<header id="masthead" class="site-header">
		<div class="site-branding">
			<?php
			the_custom_logo();
			if ( is_front_page() && is_home() ) :
				?>
				<?php
			else :
				?>
				<?php
			endif;
			$mmi_td_description = get_bloginfo( 'description', 'display' );
			if ( $mmi_td_description || is_customize_preview() ) :
				?>
				<p class="site-description"><?php echo $mmi_td_description; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
			<?php endif; ?>
		</div><!-- .site-branding -->

	<nav class="">
		<section class="flex flex-col gap-4">
			<article class="py-3 bg-redchristmas500">
			<p class="text-center text-white m-0">Nouveauté | Découvrez notre calendrier de l'Avent bio : 24 surprises pour vivre la féérie de Noël</p>
			</article>
		</section>

		<div class="flex p-4 justify-between items-center md:flex-col md:justify-between">
			<section class="flex justify-between items-center">
			<img class="w-28 object-cover" src="https://www.dafont.com/forum/attach/orig/5/5/556036.png?1" alt="">
			<ul class="hidden md:flex items-center pr-10 text-base font-semibold cursor-pointer list-none">
				<li class="flex flex-col items-center justify-around py-4 px-6">
				<span class="relative">
					<input class="flex justify-between border-2 w-96 p-2 border-grey200 focus:border-2 focus:border-grey200" type="search" id="flex justify-between border-2 w-96 p-2 border-grey200 focus:border-2 focus:border-grey200" placeholder="Que recherchez-vous ?">
					<img class="absolute inset-y-3 right-3 flex items-center" src="assets/Icons/Search.svg" alt="">
				</span>
				</li>
				<li class="flex flex-col items-center justify-around hover:bg-grey200 py-4 px-6">
				<img class="flex flex-col items-center justify-around" src="assets/Icons/Aide.svg" alt="">
				Aide
				</li>
				<li class="flex flex-col items-center justify-around hover:bg-grey200 py-4 px-6">
				<img class="flex flex-col items-center justify-around" src="assets/Icons/Boutiques.svg" alt="">
				Boutiques
				</li>
				<li class="flex flex-col items-center justify-around hover:bg-grey200 py-4 px-6">

				<div class="relative inline-block text-left">
					<div class="group">
					<button type="button" class="flex flex-col items-center justify-around w-full px-4 py-2 text-sm font-medium ">
						<img src="assets/Icons/Profil.svg" alt="">
						Profil
					</button>

					<div
						class="absolute flex left-0 w-80 mt-1 origin-top-left bg-white rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition duration-300">
						<div class="py-1 m-4">
						<p class="pl-1 m-4 font-bold">Mon compte</p>

						<a href="#" class="flex gap-4 ml-4 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
							<img class="w-auto" src="assets/Icons/Profil.svg" alt="">
							Mon compte
						</a>
						<a href="#" class="flex gap-4 ml-4 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
							<img class="w-auto" src="assets/Icons/Cartes.svg" alt="">
							Mes informations
						</a>
						<a href="#" class="flex gap-4 ml-4 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
							<img class="w-auto" src="assets/Icons/Boutiques.svg" alt="">
							Mon carnet d'adresses
						</a>
						<a href="#" class="flex gap-4 ml-4 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
							<img class="w-auto" src="assets/Icons/Box.svg" alt="">
							Mes commandes
						</a>
						<a href="#" class="flex gap-4 ml-4 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
							<img class="w-auto" src="assets/Icons/Personne.svg" alt="">
							Mon espace Kusmiklub</a>
						<a href="#"
							class="my-4 bg-black text-white flex justify-center ml-4 px-4 py-2 text-sm text-gray-700 uppercase font-bold hover:bg-white hover:text-black hover:border-2 p-8">
							Déconnexion</a>
						</div>
					</div>
					</div>
				</div>

				</li>
				<li class="flex flex-col items-center justify-around hover:bg-grey200 py-4 px-6">
				<a href="http://sae301.fr/panier/"><img class="flex flex-col items-center justify-around" src="assets/Icons/Panier.svg" alt="">
				Panier</a>
				</li>
			</ul>

			<button class="block md:hidden rounded bg-transparent border-none focus:outline-none group z-20">
				<figure>
					<div class="w-5 h-1 bg-grey600 mb-1"></div>
					<div class="w-5 h-1 bg-grey600 mb-1"></div>
					<div class="w-5 h-1 bg-grey600 mb-1"></div>
				</figure>

				<section
				class="absolute top-0 -right-full h-screen bg-white border opacity-0 group-focus:right-0 group-focus:opacity-100 transition-all duration-300">
				<ul class="flex flex-col gap-3 justify-center items-start w-full h-full cursor-pointer pt-10 list-none">
					<li class="flex flex-col items-center justify-around py-4 px-6 w-full">
					<span class="relative">
						<input class="flex justify-between border-2 w-full p-2 border-grey200 focus:border-2 focus:border-grey200" type="search" placeholder="Rechercher">
						<img class="absolute inset-y-3 right-3 flex items-center" src="assets/Icons/Search.svg" alt="">
					</span>
					</li>
					<li>
					<ul class="flex justify-around items-start flex-col gap-1 list-none">
						<li class="">
						<a class="flex px-10 py-2 uppercase font-lato self-center text-titlenavspe visited:text-titlenavspe text-xl hover:border-titlenavspe hover:border-b-2" href="">Editions spéciales</a>
						</li>
						<li class="">
						<a class="flex px-10 py-2 uppercase font-lato self-center text-redchristmas500 visited:text-redchristmas500 text-xl hover:border-b-2 hover:border-redchristmas500" href="">Offres du moment</a>
						</li>
						<li class="">
						<a class="flex px-10 py-2 uppercase font-lato self-center text-xl text-titlenav visited:text-titlenav hover:border-b-2 hover:border-black" href="">Nos thés</a>
						</li>
						<li class="">
						<a class="flex px-10 py-2 uppercase font-lato self-center text-xl text-titlenav visited:text-titlenav hover:border-b-2 hover:border-black" href="">Nos infusions</a>
						</li>
						<li class="">
						<a class="flex px-10 py-2 uppercase font-lato self-center text-xl text-titlenav visited:text-titlenav hover:border-b-2 hover:border-black" href="">Accessoires</a>
						</li>
						<li class="">
						<a class="flex px-10 py-2 uppercase font-lato self-center text-xl text-titlenav visited:text-titlenav hover:border-b-2 hover:border-black" href="">La marque</a>
						</li>
						<li class="">
						<a class="flex px-10 py-2 uppercase font-lato self-center text-xl text-titlenav visited:text-titlenav hover:border-b-2 hover:border-black" href="">Mon compte</a>
						</li>
					</ul>
					</li>
					<li class="flex flex-col items-center justify-around hover:bg-grey200 py-4 px-6 w-full">
					<img class="flex flex-col items-center" src="assets/Icons/Aide.svg" alt="">
					Aide
					</li>
					<li class="flex flex-col items-center justify-around hover:bg-grey200 py-4 px-6 w-full">
					<img class="flex flex-col items-center" src="assets/Icons/Boutiques.svg" alt="">
					Boutiques
					</li>
					<li class="flex flex-col items-center justify-around hover:bg-grey200 py-4 px-6 w-full">
					<img class="flex flex-col items-center" src="assets/Icons/Panier.svg" alt="">
					Panier
					</li>

				</ul>
				</section>
			</button>
			</section>

			<ul class="justify-around hidden md:flex list-none">
			<li class="">
				<a class="flex px-10 py-2 uppercase font-lato self-center text-xl text-titlenavspe visited:text-titlenavspe hover:border-b-2 hover:border-titlenavspe" href="http://sae301.fr/page-d-accueil/">Editions spéciales</a>
			</li>
			<li class="">
				<a class="flex px-10 py-2 uppercase font-lato self-center text-xl text-titlenavoffre visited:text-titlenavoffre hover:border-b-2 hover:border-titlenavoffre" href="">Offres du moment</a>
			</li>
			<li class="">
				<a class="flex px-10 py-2 uppercase font-lato self-center text-xl text-titlenav visited:text-titlenav hover:border-b-2 hover:border-black" href="http://sae301.fr/nos-thes/">Nos thés</a>
			</li>
			<li class="">
				<a class="flex px-10 py-2 uppercase font-lato self-center text-xl text-titlenav visited:text-titlenav hover:border-b-2 hover:border-black" href="http://sae301.fr/nos-infusions/">Nos infusions</a>
			</li>
			<li class="">
				<a class="flex px-10 py-2 uppercase font-lato self-center text-xl text-titlenav visited:text-titlenav hover:border-b-2 hover:border-black" href="http://sae301.fr/nos-accessoires/">Accessoires</a>
			</li>
			<li class="">
				<a class="flex px-10 py-2 uppercase font-lato self-center text-xl text-titlenav visited:text-titlenav hover:border-b-2 hover:border-black" href="">La marque</a>
			</li>
			</ul>
		</div>
		</nav>


		<nav id="site-navigation" class="main-navigation">

			
			<?php
			?>
		</nav><!-- #site-navigation -->

		
	</header><!-- #masthead -->
