/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {
      colors: {
        'blue' : 'hsl(212, 100%, 50%)',
        'card-forground-clr' : 'hsl(0, 0%, 100%)',
        'light-blue' : 'hsl(217, 20%, 51%)',
        'card-bg-clr' : 'hsl(221, 41%, 20%)',
        'bg-clr' : 'hsl(219, 39%, 13%)',
        'link-disabled-clr' : 'hsl(218, 36%, 45%)',
        'very-ligh-blue' : 'hsl(227, 100%, 98%)',
        'very-dark-blue' : 'hsl(217, 21%, 21%)',
        'bg-stats-clr' : 'hsla(216, 32%, 13%, 1)'
      },
      fontFamily: {
        spaceMono : ['Space Mono', 'sans-serif']
      },
    },
  },
  plugins: [],
}
