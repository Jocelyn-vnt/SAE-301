<?php
/**
 * MMI TD functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package MMI_TD
 */

 function theme_enqueue_styles() {
	wp_enqueue_style('tailwind-style', get_template_directory_uri().'/tailwind_output.css', array(), '1.0');
}

add_action('wp_enqueue_scripts', 'theme_enqueue_styles');

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.0' );
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function mmi_td_setup() {
	/*
		* Make theme available for translation.
		* Translations can be filed in the /languages/ directory.
		* If you're building a theme based on MMI TD, use a find and replace
		* to change 'mmi-td' to the name of your theme in all the template files.
		*/
	load_theme_textdomain( 'mmi-td', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
		* Let WordPress manage the document title.
		* By adding theme support, we declare that this theme does not use a
		* hard-coded <title> tag in the document head, and expect WordPress to
		* provide it for us.
		*/
	add_theme_support( 'title-tag' );

	/*
		* Enable support for Post Thumbnails on posts and pages.
		*
		* @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		*/
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus(
		array(
			'menu-1' => esc_html__( 'Primary', 'mmi-td' ),
		)
	);

	/*
		* Switch default core markup for search form, comment form, and comments
		* to output valid HTML5.
		*/
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Set up the WordPress core custom background feature.
	add_theme_support(
		'custom-background',
		apply_filters(
			'mmi_td_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);
}
add_action( 'after_setup_theme', 'mmi_td_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function mmi_td_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'mmi_td_content_width', 640 );
}
add_action( 'after_setup_theme', 'mmi_td_content_width', 0 );

/**
 * Enqueue scripts and styles.
 */
function mmi_td_scripts() {
    // style css
	wp_enqueue_style( 'mmi-td-style', get_stylesheet_uri(), array(), _S_VERSION );
	wp_enqueue_style( 'tailwind', 'https://cdn.tailwindcss.com', array(), _S_VERSION );
	wp_enqueue_style( 'custom-style', get_template_directory_uri().'/output/output.css');

    // style js
	wp_enqueue_style( 'custom-script', get_template_directory_uri().'/output/output.js');
}
add_action( 'wp_enqueue_scripts', 'mmi_td_scripts' );

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

// Register Custom Post Type
function custom_post_type_object() {

	$labels = array(
		'name'                  => _x( 'Objets', 'Post Type General Name', 'text_domain' ),
		'singular_name'         => _x( 'Objet', 'Post Type Singular Name', 'text_domain' ),
		'menu_name'             => __( 'Objets', 'text_domain' ),
		'name_admin_bar'        => __( 'Objet', 'text_domain' ),
		'archives'              => __( 'Item Archives', 'text_domain' ),
		'attributes'            => __( 'Item Attributes', 'text_domain' ),
		'parent_item_colon'     => __( 'Parent Item:', 'text_domain' ),
		'all_items'             => __( 'All Items', 'text_domain' ),
		'add_new_item'          => __( 'Add New Item', 'text_domain' ),
		'add_new'               => __( 'Add New', 'text_domain' ),
		'new_item'              => __( 'New Item', 'text_domain' ),
		'edit_item'             => __( 'Edit Item', 'text_domain' ),
		'update_item'           => __( 'Update Item', 'text_domain' ),
		'view_item'             => __( 'View Item', 'text_domain' ),
		'view_items'            => __( 'View Items', 'text_domain' ),
		'search_items'          => __( 'Search Item', 'text_domain' ),
		'not_found'             => __( 'Not found', 'text_domain' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'text_domain' ),
		'featured_image'        => __( 'Featured Image', 'text_domain' ),
		'set_featured_image'    => __( 'Set featured image', 'text_domain' ),
		'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
		'use_featured_image'    => __( 'Use as featured image', 'text_domain' ),
		'insert_into_item'      => __( 'Insert into item', 'text_domain' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'text_domain' ),
		'items_list'            => __( 'Items list', 'text_domain' ),
		'items_list_navigation' => __( 'Items list navigation', 'text_domain' ),
		'filter_items_list'     => __( 'Filter items list', 'text_domain' ),
	);
	$args = array(
		'label'                 => __( 'Objet', 'text_domain' ),
		'description'           => __( 'Type de contenu \"Objet\"', 'text_domain' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor' ),
		'taxonomies'            => array( 'main_color' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-format-aside',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
        'rewrite' => array(
            'slug'                  => 'objets',
        ),
		'show_in_rest'          => true,
	);
	register_post_type( 'object', $args );

}
add_action( 'init', 'custom_post_type_object', 0 );

// Register Custom Taxonomy
function custom_taxonomy_main_color() {

	$labels = array(
		'name'                       => _x( 'Couleurs principales', 'Taxonomy General Name', 'text_domain' ),
		'singular_name'              => _x( 'Couleur principale', 'Taxonomy Singular Name', 'text_domain' ),
		'menu_name'                  => __( 'Couleurs principales', 'text_domain' ),
		'all_items'                  => __( 'All Items', 'text_domain' ),
		'parent_item'                => __( 'Parent Item', 'text_domain' ),
		'parent_item_colon'          => __( 'Parent Item:', 'text_domain' ),
		'new_item_name'              => __( 'New Item Name', 'text_domain' ),
		'add_new_item'               => __( 'Add New Item', 'text_domain' ),
		'edit_item'                  => __( 'Edit Item', 'text_domain' ),
		'update_item'                => __( 'Update Item', 'text_domain' ),
		'view_item'                  => __( 'View Item', 'text_domain' ),
		'separate_items_with_commas' => __( 'Separate items with commas', 'text_domain' ),
		'add_or_remove_items'        => __( 'Add or remove items', 'text_domain' ),
		'choose_from_most_used'      => __( 'Choose from the most used', 'text_domain' ),
		'popular_items'              => __( 'Popular Items', 'text_domain' ),
		'search_items'               => __( 'Search Items', 'text_domain' ),
		'not_found'                  => __( 'Not Found', 'text_domain' ),
		'no_terms'                   => __( 'No items', 'text_domain' ),
		'items_list'                 => __( 'Items list', 'text_domain' ),
		'items_list_navigation'      => __( 'Items list navigation', 'text_domain' ),
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => false,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
		'show_in_rest'               => true,
		'rewitre'               => [
            'slug' => 'couleur-principal',
            'with_front' => true
        ],                
	);
	register_taxonomy( 'main_color', array( 'object' ), $args );

}
add_action( 'init', 'custom_taxonomy_main_color', 0 );

// Register Custom Post Type
function custom_post_type_recipe() {

	$labels = array(
		'name'                  => _x( 'Recettes', 'Post Type General Name', 'text_domain' ),
		'singular_name'         => _x( 'Recette', 'Post Type Singular Name', 'text_domain' ),
		'menu_name'             => __( 'Recettes', 'text_domain' ),
		'name_admin_bar'        => __( 'Recette', 'text_domain' ),
		'archives'              => __( 'Item Archives', 'text_domain' ),
		'attributes'            => __( 'Item Attributes', 'text_domain' ),
		'parent_item_colon'     => __( 'Parent Item:', 'text_domain' ),
		'all_items'             => __( 'All Items', 'text_domain' ),
		'add_new_item'          => __( 'Add New Item', 'text_domain' ),
		'add_new'               => __( 'Add New', 'text_domain' ),
		'new_item'              => __( 'New Item', 'text_domain' ),
		'edit_item'             => __( 'Edit Item', 'text_domain' ),
		'update_item'           => __( 'Update Item', 'text_domain' ),
		'view_item'             => __( 'View Item', 'text_domain' ),
		'view_items'            => __( 'View Items', 'text_domain' ),
		'search_items'          => __( 'Search Item', 'text_domain' ),
		'not_found'             => __( 'Not found', 'text_domain' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'text_domain' ),
		'featured_image'        => __( 'Featured Image', 'text_domain' ),
		'set_featured_image'    => __( 'Set featured image', 'text_domain' ),
		'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
		'use_featured_image'    => __( 'Use as featured image', 'text_domain' ),
		'insert_into_item'      => __( 'Insert into item', 'text_domain' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'text_domain' ),
		'items_list'            => __( 'Items list', 'text_domain' ),
		'items_list_navigation' => __( 'Items list navigation', 'text_domain' ),
		'filter_items_list'     => __( 'Filter items list', 'text_domain' ),
	);
	$rewrite = array(
		'slug'                  => 'recettes',
		'with_front'            => true,
		'pages'                 => true,
		'feeds'                 => true,
	);
	$args = array(
		'label'                 => __( 'Recette', 'text_domain' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'         => 'dashicons-buddicons-topics',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'rewrite'               => $rewrite,
		'capability_type'       => 'page',
		'show_in_rest'          => true,
	);
	register_post_type( 'recipe', $args );

}
add_action( 'init', 'custom_post_type_recipe', 0 );

/* save group of acf json */
function mmi_td_json_save_groups($path) {
	return get_stylesheet_directory() . '/inc';
}
add_filter( 'acf/settings/save_json', 'mmi_td_json_save_groups' );

function mmi_td_json_load_point($paths) {
	unset($paths[0]);
	$paths[] = get_stylesheet_directory() . '/inc';
	return $paths;
}
add_filter('acf/settings/load_json', 'mmi_td_json_load_point');

/*ENABLE MENU*/
function register_custom_menus() {
    register_nav_menus(
      array(
        'header-menu' => __('Menu Header'),
        'footer-menu' => __('Menu Footer'),
      )
    );
}
add_action('init', 'register_custom_menus');
  
/**
 * Code snippet to change WooCommerce In Stock text 
 */ 

//  add_filter( 'woocommerce_get_availability', 'change_in_stock_text', 1, 2);

//  function change_in_stock_text( $availability, $_product ) {
	 
// 	 // Change In Stock Text
// 	 if ( $_product->is_in_stock() ) {
// 		 $availability['availability'] = __('Produit en stock', 'woocommerce');
// 	 }
	
// 	 return $availability;
//  }

//  add_filter( 'woocommerce_get_availability', 'change_out_of_stock_text', 1, 2);

//  function change_out_of_stock_text( $availability, $_product ) {
	 
// 	 // Change In Stock Text
// 	 if ( !$_product->is_in_stock() ) {
// 		 $availability['availability'] = __('Temporairement indisponible', 'woocommerce');
// 	 }
	
// 	 return $availability;
//  }
 
add_filter( 'woocommerce_product_single_add_to_cart_text', 'custom_add_to_cart_text' );
add_filter( 'woocommerce_product_add_to_cart_text', 'custom_add_to_cart_text' );

function custom_add_to_cart_text() {
return __( 'Ajouter au panier', 'woocommerce' );
}

add_filter( 'woocommerce_variable_price_html', 'variation_price_format_min', 9999, 2 );
  
function variation_price_format_min( $price, $product ) {
   $prices = $product->get_variation_prices( true );
   $min_price = current( $prices['price'] );
   $price = sprintf( __( 'À partir de : %1$s', 'woocommerce' ), wc_price( $min_price ) );
   return $price;
}

add_filter( 'wc_product_sku_enabled', 'wpm_remove_sku' );

function wpm_remove_sku( $enabled ) {
	// Si on est pas dans l'admin et si on est sur la page produit
    if ( !is_admin() && is_product() ) {
        return false;
    }
    return $enabled;
}

add_action( 'init', 'woocommerce_clear_cart_url' ); function woocommerce_clear_cart_url() { if ( isset( $_GET['clear-cart'] ) ) { global $woocommerce; $woocommerce->cart->empty_cart(); } }
